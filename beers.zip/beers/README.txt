/************************************
/*
/* Open Beer Database
/* openbeerdb.com
/*
/* beers.sql
/*
/* This Open Beer Database is made available under the Open Database License: 
/* http://opendatacommons.org/licenses/odbl/1.0/. Any rights in individual 
/* contents of the database are licensed under the Database Contents License: 
/* http://opendatacommons.org/licenses/dbcl/1.0/
/*
/************************************

Any questions? admin@openbeerdb.com (subject line "beers.sql download")
